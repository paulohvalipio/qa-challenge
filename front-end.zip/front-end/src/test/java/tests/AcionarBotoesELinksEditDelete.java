package tests;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.concurrent.TimeUnit;

public class AcionarBotoesELinksEditDelete {
    @Test
    public void testAcionaBotoesELinksEditDelete() throws InterruptedException {
        //Abrindo o navegador
        System.setProperty("webdriver.chrome.driver", "C:\\drivers\\chromedriver.exe");
        WebDriver navegador = new ChromeDriver();

        //Aguarda 5 segundos para carregar todos os elementos na tela
        navegador.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

        //Acessando a aplicação web a ser automatizada
        navegador.get("https://the-internet.herokuapp.com/challenging_dom");

        //Aciona o botão Azul
        navegador.findElement(By.className("button")).click();
        //Aciona o botão Vermelho
        navegador.findElement(By.className("alert")).click();
        //Aciona o botão Verde
        navegador.findElement(By.className("success")).click();

        int posicaoEditDelete=7;
        //Verifica linha a linha da tabela e aciona as opções edit e delete
        for (int i = 1; i <= 10; i++) {
            navegador.findElement(By.xpath(".//table//tr["+i+"]//td[" + posicaoEditDelete +"]")).findElement(By.linkText("edit")).click();
            navegador.findElement(By.xpath(".//table//tr["+i+"]//td[" + posicaoEditDelete +"]")).findElement(By.linkText("delete")).click();
        }
    }
}
