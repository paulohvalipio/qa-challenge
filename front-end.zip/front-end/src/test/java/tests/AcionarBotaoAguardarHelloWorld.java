package tests;

import org.junit.Assert;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.concurrent.TimeUnit;

public class AcionarBotaoAguardarHelloWorld {
    @Test
    public void testAcionarBotaoAguardarHelloWorld() throws InterruptedException {
        //Abrindo o navegador
        System.setProperty("webdriver.chrome.driver", "C:\\drivers\\chromedriver.exe");
        WebDriver navegador = new ChromeDriver();

        //Aguarda 5 segundos para carregar todos os elementos na tela
        navegador.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

        //Acessando a aplicação web a ser automatizada
        navegador.get("https://the-internet.herokuapp.com/dynamic_loading/1");

        //Clicar no botão "Start" utilizando xpath
        navegador.findElement(By.xpath("//div[@id=\"start\"]//button")).click();

        //Aguarda 5 segundos para finalizar o carregamento da barra de progresso
        Thread.sleep(5000);

        //Identifica a descrição "Hello World" utilizando xpath
        WebElement descricaoHelloWorld = navegador.findElement(By.xpath("//div[@id=\"finish\"]//h4"));

        //Salva a descrição identificada no elemento
        String descricaoIdentificada = descricaoHelloWorld.getText();

        //Verifica se a descrição identificada é a mesma descrição esperada
        Assert.assertEquals("Hello World!", descricaoIdentificada);
    }
}
